
package com.example.screens.Data

data class Pet(
    val name: String,
    val imageRes: Int
)
